public class ConcreteProductPalio extends Car{

    public ConcreteProductPalio() {
        this.setModel("Palio");
        this.setFactory("Fiat");
        this.setCatagory("Hatch");
        this.showInformation();
    }
}
